---
id: 74
title: Coastland Mall, Florida
date: 2018-12-13T19:42:12+10:00
author: Planner
excerpt: How not to build a shopping centre
layout: revision
guid: https://planninghell.com/68-autosave-v1/
permalink: /68-autosave-v1/
---
<div class="et_pb_section et_pb_section_26 et_section_regular et_section_transparent">
  <div class="et_pb_row et_pb_row_101">
    <div class="et_pb_column et_pb_column_1_2 et_pb_column_118    et_pb_css_mix_blend_mode_passthrough">
      <div class="et_pb_module et_pb_text et_pb_text_85 et_pb_bg_layout_light  et_pb_text_align_left">
        <div class="et_pb_text_inner">
          <p>
            <strong>Naples, Florida, United States of America<br /></strong>
          </p>
        </div>
      </div>
      
      <!-- .et_pb_text -->
    </div>
    
    <!-- .et_pb_column -->
    
    <div class="et_pb_column et_pb_column_1_2 et_pb_column_119    et_pb_css_mix_blend_mode_passthrough et_pb_column_empty">
    </div>
    
    <!-- .et_pb_column -->
  </div>
  
  <!-- .et_pb_row -->
  
  <div class="et_pb_row et_pb_row_102">
    <div class="et_pb_column et_pb_column_4_4 et_pb_column_120    et_pb_css_mix_blend_mode_passthrough et-last-child">
      <div class="et_pb_module et_pb_text et_pb_text_86 et_pb_bg_layout_light  et_pb_text_align_left">
        <div class="et_pb_text_inner">
          <p>
            I barely know where to begin with this one.
          </p>
          
          <p>
            Let&#8217;s start by pointing out that this is not an unusual design in a country that is world-renown for its excellence in urban planning.
          </p>
          
          <p>
            The Coastland Centre is located in Naples, Florida. It has over 100 shops and is surrounded by an ocean of asphalt in the form of 4,500 car parking spaces. For some reason, a shop called the &#8216;Cheesecake Factory&#8217; appears to form the centrepiece of the shopping centre&#8217;s axis; an apt symbol for the obesity that everyone will suffer after being forced to drive everywhere.
          </p>
        </div>
      </div>
      
      <!-- .et_pb_text -->
    </div>
    
    <!-- .et_pb_column -->
  </div>
  
  <!-- .et_pb_row -->
  
  <div class="et_pb_row et_pb_row_103">
    <div class="et_pb_column et_pb_column_4_4 et_pb_column_121    et_pb_css_mix_blend_mode_passthrough et-last-child">
      <div class="et_pb_module et_pb_code et_pb_code_28">
        <div class="et_pb_code_inner">
        </div>
        
        <!-- .et_pb_code_inner -->
      </div>
      
      <!-- .et_pb_code -->
    </div>
    
    <!-- .et_pb_column -->
  </div>
  
  <!-- .et_pb_row -->
  
  <div class="et_pb_row et_pb_row_104">
    <div class="et_pb_column et_pb_column_4_4 et_pb_column_122    et_pb_css_mix_blend_mode_passthrough et-last-child">
      <div class="et_pb_module et_pb_text et_pb_text_87 et_pb_bg_layout_light  et_pb_text_align_left">
        <div class="et_pb_text_inner">
          <p>
            The Centre&#8217;s official website hilariously <a href="https://www.coastlandcenter.com/en/visit.html" target="_blank" rel="noopener">describes</a> the bus stop as being &#8220;conveniently located&#8221;, despite it being situated over 120 metres from the southern entrance.
          </p>
          
          <p>
            Apparently there is no room anywhere to move the bus stop close to the actual entrance to the shopping centre.
          </p>
        </div>
      </div>
      
      <!-- .et_pb_text -->
    </div>
    
    <!-- .et_pb_column -->
  </div>
  
  <!-- .et_pb_row -->
  
  <div class="et_pb_row et_pb_row_105">
    <div class="et_pb_column et_pb_column_4_4 et_pb_column_123    et_pb_css_mix_blend_mode_passthrough et-last-child">
      <div class="et_pb_module et_pb_text et_pb_text_88 et_pb_bg_layout_light  et_pb_text_align_left">
        <div class="et_pb_text_inner">
          <p>
            Very active street frontage.
          </p>
        </div>
      </div>
      
      <!-- .et_pb_text -->
      
      <div class="et_pb_module et_pb_code et_pb_code_29">
        <div class="et_pb_code_inner">
        </div>
        
        <!-- .et_pb_code_inner -->
      </div>
      
      <!-- .et_pb_code -->
    </div>
    
    <!-- .et_pb_column -->
  </div>
  
  <!-- .et_pb_row -->
</div>

<!-- .et_pb_section -->

<div class="et_pb_section et_pb_section_27 et_section_regular et_section_transparent">
  <div class="et_pb_row et_pb_row_106">
    <div class="et_pb_column et_pb_column_4_4 et_pb_column_124    et_pb_css_mix_blend_mode_passthrough et-last-child">
      <div class="et_pb_module et_pb_text et_pb_text_89 et_pb_bg_layout_light  et_pb_text_align_left">
        <div class="et_pb_text_inner">
          <h2>
            Design features
          </h2>
        </div>
      </div>
      
      <!-- .et_pb_text -->
      
      <div class="et_pb_module et_pb_text et_pb_text_90 et_pb_bg_layout_light  et_pb_text_align_left">
        <div class="et_pb_text_inner">
          <ul>
            <li>
              Only one access point for pedestrians
            </li>
            <li>
              No bike infrastructure or parking
            </li>
            <li>
              Completely insane oversupply of car parking
            </li>
            <li>
              Parking lots with basically no shade (in a sunny climate)
            </li>
            <li>
              Entry/exit points for cars onto a main road <a href="https://goo.gl/maps/Z9xcUEqAnwJ2" target="_blank" rel="noopener">in the wrong direction</a> for some reason
            </li>
            <li>
              Only has an hourly bus service that does not operate on Sundays (because nobody goes shopping on a weekend, right?)
            </li>
          </ul>
        </div>
      </div>
      
      <!-- .et_pb_text -->
    </div>
    
    <!-- .et_pb_column -->
  </div>
  
  <!-- .et_pb_row -->
</div>

<!-- .et_pb_section -->