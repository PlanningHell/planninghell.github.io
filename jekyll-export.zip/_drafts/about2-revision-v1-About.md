---
id: 163
title: About
date: 2020-04-27T19:24:26+10:00
author: Planner
layout: revision
guid: https://planninghell.com/2-revision-v1/
permalink: /2-revision-v1/
---
I am a planner. And I am fed up.

Inspired by all of the shit that we have built in our cities, this site aims to make people more aware of the horrible design and urban planning that is going on around us.

_Want to know more about planning? The American Planning Association has a useful summary here:_ <a href="https://www.planning.org/aboutplanning/" target="_blank" rel="noopener noreferrer"><em>https://www.planning.org/aboutplanning/</em></a>