---
id: 194
title: Aspect Estate, Greenvale
date: 2020-07-12T09:32:05+10:00
author: Planner
excerpt: We are still building these estates in 2018 apparently.
layout: revision
guid: https://planninghell.com/54-autosave-v1/
permalink: /54-autosave-v1/
---
<div class="et_pb_section et_pb_section_37 et_section_regular et_section_transparent">
  <div class="et_pb_row et_pb_row_136">
    <div class="et_pb_column et_pb_column_1_2 et_pb_column_158    et_pb_css_mix_blend_mode_passthrough">
      <div class="et_pb_module et_pb_text et_pb_text_117 et_pb_bg_layout_light  et_pb_text_align_left">
        <div class="et_pb_text_inner">
          <p>
            <strong>Greenvale, Victoria, Australia</strong>
          </p>
        </div>
      </div>
      
      <!-- .et_pb_text -->
    </div>
    
    <!-- .et_pb_column -->
    
    <div class="et_pb_column et_pb_column_1_2 et_pb_column_159    et_pb_css_mix_blend_mode_passthrough et_pb_column_empty">
    </div>
    
    <!-- .et_pb_column -->
  </div>
  
  <!-- .et_pb_row -->
  
  <div class="et_pb_row et_pb_row_137">
    <div class="et_pb_column et_pb_column_4_4 et_pb_column_160    et_pb_css_mix_blend_mode_passthrough et-last-child">
      <div class="et_pb_module et_pb_text et_pb_text_118 et_pb_bg_layout_light  et_pb_text_align_left">
        <div class="et_pb_text_inner">
          <p>
            Aspect Estate is located in one of the newer parts of the fast-growing parts of northern Melbourne.
          </p>
          
          <p>
            It has all of the modern features you can expect, including dark-coloured walls facing north, bike lanes to nowhere and a street network that will be very safe in an bushfire with its single entry/exit point. Enjoy!
          </p>
        </div>
      </div>
      
      <!-- .et_pb_text -->
    </div>
    
    <!-- .et_pb_column -->
  </div>
  
  <!-- .et_pb_row -->
  
  <div class="et_pb_row et_pb_row_138">
    <div class="et_pb_column et_pb_column_4_4 et_pb_column_161    et_pb_css_mix_blend_mode_passthrough et-last-child">
      <div class="et_pb_module et_pb_code et_pb_code_38">
        <div class="et_pb_code_inner">
        </div>
        
        <!-- .et_pb_code_inner -->
      </div>
      
      <!-- .et_pb_code -->
    </div>
    
    <!-- .et_pb_column -->
  </div>
  
  <!-- .et_pb_row -->
  
  <div class="et_pb_row et_pb_row_139">
    <div class="et_pb_column et_pb_column_4_4 et_pb_column_162    et_pb_css_mix_blend_mode_passthrough et-last-child">
      <div class="et_pb_module et_pb_text et_pb_text_119 et_pb_bg_layout_light  et_pb_text_align_left">
        <div class="et_pb_text_inner">
          <h2>
            Design features
          </h2>
        </div>
      </div>
      
      <!-- .et_pb_text -->
      
      <div class="et_pb_module et_pb_text et_pb_text_120 et_pb_bg_layout_light  et_pb_text_align_left">
        <div class="et_pb_text_inner">
          <ul>
            <li>
              Black roofs in a sunny climate
            </li>
            <li>
              Mosquito-breeding centre (the stagnant water to the south)
            </li>
            <li>
              Identical house designs
            </li>
            <li>
              Naff street names (see &#8216;Inspiration Way&#8217;)
            </li>
            <li>
              Footpaths on one side of the street
            </li>
            <li>
              Unnecessary &#8220;aesthetic&#8221; curves in street layout
            </li>
            <li>
              Single entry/exit point
            </li>
            <li>
              <a href="https://goo.gl/maps/fne6etjXRKL2">Footpaths to nowhere</a>
            </li>
          </ul>
        </div>
      </div>
      
      <!-- .et_pb_text -->
    </div>
    
    <!-- .et_pb_column -->
  </div>
  
  <!-- .et_pb_row -->
  
  <div class="et_pb_row et_pb_row_140">
    <div class="et_pb_column et_pb_column_4_4 et_pb_column_163    et_pb_css_mix_blend_mode_passthrough et-last-child et_pb_column_empty">
    </div>
    
    <!-- .et_pb_column -->
  </div>
  
  <!-- .et_pb_row -->
</div>

<!-- .et_pb_section -->