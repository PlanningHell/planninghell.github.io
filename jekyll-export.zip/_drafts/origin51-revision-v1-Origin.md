---
id: 126
title: Origin
date: 2019-12-03T20:39:00+10:00
author: Planner
layout: revision
guid: https://planninghell.com/51-revision-v1/
permalink: /51-revision-v1/
---
li{  
margin-top: 10px;  
}

li:first-child {  
margin-top:0;  
}