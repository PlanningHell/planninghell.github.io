---
id: 139
title: Bad developments and awards
date: 2020-04-27T19:25:09+10:00
author: Planner
layout: post
guid: https://planninghell.com/?p=139
permalink: /?p=139
categories:
  - Uncategorised
---
https://www.facebook.com/groups/226335894721316/permalink/330490360972535/