---
id: 96
date: 2019-01-25T16:36:34+10:00
author: Planner
layout: revision
guid: https://planninghell.com/94-autosave-v1/
permalink: /94-autosave-v1/
---
<div class="et_pb_section et_pb_section_33 et_section_regular et_section_transparent">
  <div class="et_pb_row et_pb_row_124">
    <div class="et_pb_column et_pb_column_1_2 et_pb_column_144    et_pb_css_mix_blend_mode_passthrough">
      <div class="et_pb_module et_pb_text et_pb_text_105 et_pb_bg_layout_light  et_pb_text_align_left">
        <div class="et_pb_text_inner">
          <p>
            <strong>Mulgrave, Victoria Australia<br /></strong>
          </p>
        </div>
      </div>
      
      <!-- .et_pb_text -->
    </div>
    
    <!-- .et_pb_column -->
    
    <div class="et_pb_column et_pb_column_1_2 et_pb_column_145    et_pb_css_mix_blend_mode_passthrough et_pb_column_empty">
    </div>
    
    <!-- .et_pb_column -->
  </div>
  
  <!-- .et_pb_row -->
  
  <div class="et_pb_row et_pb_row_125">
    <div class="et_pb_column et_pb_column_4_4 et_pb_column_146    et_pb_css_mix_blend_mode_passthrough et-last-child">
      <div class="et_pb_module et_pb_text et_pb_text_106 et_pb_bg_layout_light  et_pb_text_align_left">
        <div class="et_pb_text_inner">
          <p>
            One of the most notorious intersections in Melbourne. Springvale Road, Dandenong Road, Centre Road and Police Road all meet at this incredibly disaster of an intersection.
          </p>
        </div>
      </div>
      
      <!-- .et_pb_text -->
    </div>
    
    <!-- .et_pb_column -->
  </div>
  
  <!-- .et_pb_row -->
  
  <div class="et_pb_row et_pb_row_126">
    <div class="et_pb_column et_pb_column_4_4 et_pb_column_147    et_pb_css_mix_blend_mode_passthrough et-last-child">
      <div class="et_pb_module et_pb_code et_pb_code_34">
        <div class="et_pb_code_inner">
        </div>
        
        <!-- .et_pb_code_inner -->
      </div>
      
      <!-- .et_pb_code -->
    </div>
    
    <!-- .et_pb_column -->
  </div>
  
  <!-- .et_pb_row -->
  
  <div class="et_pb_row et_pb_row_127">
    <div class="et_pb_column et_pb_column_4_4 et_pb_column_148    et_pb_css_mix_blend_mode_passthrough et-last-child">
      <div class="et_pb_module et_pb_text et_pb_text_107 et_pb_bg_layout_light  et_pb_text_align_left">
        <div class="et_pb_text_inner">
          <p>
            The Centre&#8217;s official website hilariously <a href="https://www.coastlandcenter.com/en/visit.html" target="_blank" rel="noopener">describes</a> the bus stop as being &#8220;conveniently located&#8221;, despite it being situated over 120 metres from the southern entrance.
          </p>
          
          <p>
            Apparently there is no room anywhere to move the bus stop close to the actual entrance to the shopping centre.
          </p>
        </div>
      </div>
      
      <!-- .et_pb_text -->
    </div>
    
    <!-- .et_pb_column -->
  </div>
  
  <!-- .et_pb_row -->
  
  <div class="et_pb_row et_pb_row_128">
    <div class="et_pb_column et_pb_column_4_4 et_pb_column_149    et_pb_css_mix_blend_mode_passthrough et-last-child">
      <div class="et_pb_module et_pb_text et_pb_text_108 et_pb_bg_layout_light  et_pb_text_align_left">
        <div class="et_pb_text_inner">
          <p>
            Also enjoy this very active street frontage.
          </p>
        </div>
      </div>
      
      <!-- .et_pb_text -->
      
      <div class="et_pb_module et_pb_code et_pb_code_35">
        <div class="et_pb_code_inner">
        </div>
        
        <!-- .et_pb_code_inner -->
      </div>
      
      <!-- .et_pb_code -->
    </div>
    
    <!-- .et_pb_column -->
  </div>
  
  <!-- .et_pb_row -->
</div>

<!-- .et_pb_section -->

<div class="et_pb_section et_pb_section_34 et_section_regular et_section_transparent">
  <div class="et_pb_row et_pb_row_129">
    <div class="et_pb_column et_pb_column_4_4 et_pb_column_150    et_pb_css_mix_blend_mode_passthrough et-last-child">
      <div class="et_pb_module et_pb_text et_pb_text_109 et_pb_bg_layout_light  et_pb_text_align_left">
        <div class="et_pb_text_inner">
          <h2>
            Design features
          </h2>
        </div>
      </div>
      
      <!-- .et_pb_text -->
      
      <div class="et_pb_module et_pb_text et_pb_text_110 et_pb_bg_layout_light  et_pb_text_align_left">
        <div class="et_pb_text_inner">
          <ul>
            <li>
              Only one access point for pedestrians
            </li>
            <li>
              No bike infrastructure or parking
            </li>
            <li>
              Completely insane oversupply of car parking
            </li>
            <li>
              Parking lots with basically no shade (in a sunny climate)
            </li>
            <li>
              Entry/exit points for cars onto a main road <a href="https://goo.gl/maps/Z9xcUEqAnwJ2" target="_blank" rel="noopener">in the wrong direction</a> for some reason
            </li>
            <li>
              Only has an hourly bus service that does not operate on Sundays (because nobody goes shopping on a weekend, right?)
            </li>
          </ul>
        </div>
      </div>
      
      <!-- .et_pb_text -->
    </div>
    
    <!-- .et_pb_column -->
  </div>
  
  <!-- .et_pb_row -->
</div>

<!-- .et_pb_section -->