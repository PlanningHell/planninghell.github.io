---
id: 169
title: twentytwenty
date: 2020-04-27T19:32:55+10:00
author: Planner
layout: revision
guid: https://planninghell.com/168-revision-v1/
permalink: /168-revision-v1/
---
.entry-content > *:not(.alignwide):not(.alignfull):not(.alignleft):not(.alignright):not(.is-style-wide) {  
max-width: 87rem;  
width: calc(100% &#8211; 8rem);  
}