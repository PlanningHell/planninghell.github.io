---
id: 63
title: Sample Page
date: 2018-12-09T09:14:16+10:00
author: Planner
layout: revision
guid: https://planninghell.com/2-autosave-v1/
permalink: /2-autosave-v1/
---
I am a planner. And I am fed up.

Inspired by all of the shit that we have built in our cities, this site aims to make people more aware of the horrible design and urban planning that is going on around us. Especially badly-designed suburbs that are unhealthy, environmentally-destructive and fundamen

Want to know more about planning? The American Planning Association has a useful summary here: <a href="https://www.planning.org/aboutplanning/" target="_blank" rel="noopener">https://www.planning.org/aboutplanning/</a>