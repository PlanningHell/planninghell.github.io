---
id: 190
title: Why does Eynesbury exist?
date: 2020-07-10T21:40:36+10:00
author: Planner
layout: post
guid: https://planninghell.com/?p=190
permalink: /?p=190
categories:
  - Uncategorised
---
If you&#8217;ve ever heard of this inky stain on the landscape of Victoria, well done. Your brain has been damaged already, purely by exposure to such a cesspool of bad planning and design.  
  
If not and your mind is unsullied by such filth, then read on to find out more.

Eynesbury is everything that good planning is not.

Built in the early 2000s using a loophole in planning laws that are meant to protect green space on the edges of Melbourne, this &#8220;township&#8221; is a cluster of 99.99% residential suburban hell in the middle of nowhere.

Not even the &#8220;free market&#8221; wants to touch this place with a bargepole. It says a lot when it has changed ownership &#8220;<a rel="noreferrer noopener" href="https://en.wikipedia.org/wiki/Eynesbury,_Victoria#Financial_issues" target="_blank">several times</a>&#8221; and its developers have spent a lot of time in Victoria&#8217;s court system.