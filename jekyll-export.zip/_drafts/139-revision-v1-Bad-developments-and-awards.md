---
id: 143
title: Bad developments and awards
date: 2020-02-22T21:40:40+10:00
author: Planner
layout: revision
guid: https://planninghell.com/139-revision-v1/
permalink: /139-revision-v1/
---
https://www.facebook.com/groups/226335894721316/permalink/330490360972535/